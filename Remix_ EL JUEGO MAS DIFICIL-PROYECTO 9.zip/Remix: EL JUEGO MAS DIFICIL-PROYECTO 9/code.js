var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","41a919c2-6959-47b2-9647-8f6ee687b4c6","c43ec3ca-cf90-4e79-a4dd-5bf1cdef697f","9c3cfee3-1231-4d43-bfa2-42246dee26fd","894af581-8f0c-45fb-81f4-3b903f0bca97","d481ec74-cc15-423b-b760-def4d92d45cd","8a15262f-3848-4fbd-98b8-35a7404bea12","caeb5d88-0aa1-4be5-bb71-61af72869108"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"kADxjmaVn9EyoCQan7WbzEAIt_wdz3N0","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"AQMJVpEk.YeBZH0_2glC5cr.vm4J_Hdu","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"w9IeMBM46...iOhYj4oaPfEfGv5beW7a","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"41a919c2-6959-47b2-9647-8f6ee687b4c6":{"name":"space_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"},"c43ec3ca-cf90-4e79-a4dd-5bf1cdef697f":{"name":"playerShip2_red_1","sourceUrl":null,"frameSize":{"x":60,"y":40},"frameCount":1,"looping":true,"frameDelay":12,"version":"qB_FW2crhLD8EkbX0UA5a4tA7NNlHtsk","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":60,"y":40},"rootRelativePath":"assets/c43ec3ca-cf90-4e79-a4dd-5bf1cdef697f.png"},"9c3cfee3-1231-4d43-bfa2-42246dee26fd":{"name":"ship10_1","sourceUrl":null,"frameSize":{"x":40,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"s4S2iIRlQbPg1B6tVw59VrpxcTD1yBMh","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":40,"y":30},"rootRelativePath":"assets/9c3cfee3-1231-4d43-bfa2-42246dee26fd.png"},"894af581-8f0c-45fb-81f4-3b903f0bca97":{"name":"ship05_1","sourceUrl":null,"frameSize":{"x":40,"y":55},"frameCount":1,"looping":true,"frameDelay":12,"version":"i15l8PWVqPsCJuBDyrAfGTb7L4.PY4ci","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":40,"y":55},"rootRelativePath":"assets/894af581-8f0c-45fb-81f4-3b903f0bca97.png"},"d481ec74-cc15-423b-b760-def4d92d45cd":{"name":"ship17_1","sourceUrl":null,"frameSize":{"x":40,"y":27},"frameCount":1,"looping":true,"frameDelay":12,"version":"sGAbLhPzzLMkJD9dAIohpPmruk56oN_1","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":40,"y":27},"rootRelativePath":"assets/d481ec74-cc15-423b-b760-def4d92d45cd.png"},"8a15262f-3848-4fbd-98b8-35a7404bea12":{"name":"ship16_1","sourceUrl":null,"frameSize":{"x":40,"y":54},"frameCount":1,"looping":true,"frameDelay":12,"version":"b87nsZ0ZkzRkvTmw6zNtF3KlUoOIy_ty","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":40,"y":54},"rootRelativePath":"assets/8a15262f-3848-4fbd-98b8-35a7404bea12.png"},"caeb5d88-0aa1-4be5-bb71-61af72869108":{"name":"PLANETA TIERRA.jpg_1","sourceUrl":null,"frameSize":{"x":50,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"RIwCpKgTqmd3K8kkzd4PqG5E9bc58iA.","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":50},"rootRelativePath":"assets/caeb5d88-0aa1-4be5-bb71-61af72869108.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var espacio = createSprite (200,200);
espacio.setAnimation("space_1");

var jugador = createSprite (200,370);
jugador.setAnimation("playerShip2_red_1");

var A = createSprite (30,320);
A.setAnimation("ship10_1");
var laser1 = createSprite (80,320,50,5);
laser1.shapeColor = "red";
laser1.velocityX=10;

var B = createSprite (370,240);
B.setAnimation("ship05_1");
var laser2 = createSprite (320,240,50,5);
laser2.shapeColor = "red";
laser2.velocityX=10;

var C = createSprite (30,100);
C.setAnimation("ship17_1");
var laser3 = createSprite (80,100,50,5);
laser3.shapeColor = "red";
laser3.velocityX=10;

var D = createSprite (370,180);
D.setAnimation("ship16_1");
var laser4 = createSprite(320,180,50,5);
laser4.shapeColor = "red";
laser4.velocityX = 10;

var Planeta = createSprite (200,50);
Planeta.setAnimation("PLANETA TIERRA.jpg_1");

var goal = 0;
var death = 0;
function draw()
{
drawSprites();
textSize("20");
fill("white");
text("goal: "+goal,300,20);
text("death: "+death,300,40);

createEdgeSprites();

jugador.bounceOff(edges);

laser1.bounceOff(edges);
laser1.bounceOff(A);

laser2.bounceOff(edges);
laser2.bounceOff(B);

laser3.bounceOff(edges);
laser3.bounceOff(C);

laser4.bounceOff(edges);
laser4.bounceOff(D);

if(keyDown("up"))
{
jugador.y = jugador.y-3;
}
if(keyDown("down")){
jugador.y = jugador.y+3;
}
if(keyDown("left"))
{
jugador.x = jugador.x-3;
}
if(keyDown("right"))
{
jugador.x = jugador.x+3;  
}
if(jugador.isTouching(laser1) || jugador.isTouching(laser2) || jugador.isTouching(laser3) || jugador.isTouching(laser4)){
playSound("assets/category_hits/vibrant_game_big_hit_1.mp3");  
jugador.x=200;
jugador.y=370;
death= death+1;
}
if(jugador.isTouching(A) || jugador.isTouching(B) || jugador.isTouching(C) || jugador.isTouching(D)){
playSound("assets/category_hits/vibrant_game_big_hit_1.mp3");
jugador.x=200;
jugador.y=370;
death= death+1;
}
if(jugador.isTouching(Planeta)){
playSound("assets/category_instrumental/marimba_upscale_1.mp3");
jugador.x=200;
jugador.y=370;
goal = goal+1;
}
if(goal==3){
textSize(30);
fill("yellow");
text("¡GANASTE!",120,130);
laser1.velocityX=0;
laser2.velocityX=0;
laser3.velocityX=0;
laser4.velocityX=0;
jugador.x=200;
jugador.y=370;
laser1.x= 80;
laser1.y= 320;
laser2.x=320;
laser2.y=240;
laser3.x=80;
laser3.y=100;
laser4.x=320;
laser4.y=180;
}
if(death==5){
textSize(30);
fill("red");
text("¡PERDISTE!",120,130);
laser1.velocityX=0;
laser2.velocityX=0;
laser3.velocityX=0;
laser4.velocityX=0;
jugador.x=200;
jugador.y=370;
laser1.x= 80;
laser1.y= 320;
laser2.x=320;
laser2.y=240;
laser3.x=80;
laser3.y=100;
laser4.x=320;
laser4.y=180;
}
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
